module.exports = {
  extends: require.resolve('@popperjs/eslint-config-popper'),
};
